function [link_metric, node_metric]=ps_metric(n_v,stay_time,n_list)

for i=1:n_v
    for j=1:n_v
        PSI(i,j)=stay_time(i,j);
     end
end



for i=1:n_v
    if(isempty(n_list{i}))
        PS(i)=0;
    else
    PS(i)=mean(stay_time(i,n_list{i}));
    end
end

link_metric=PSI;
node_metric=PS;