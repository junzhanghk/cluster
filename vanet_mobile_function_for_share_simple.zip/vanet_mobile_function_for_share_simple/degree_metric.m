function [node_metric]=degree_metric(n_v,dist,speed,loc,vd,max_dist,t_start,t_end,n_list)

for i=1:n_v
    if(isempty(n_list{i}))
        DEG(i)=0;
    else
    DEG(i)=length(n_list{i});
    end
end

node_metric=DEG;