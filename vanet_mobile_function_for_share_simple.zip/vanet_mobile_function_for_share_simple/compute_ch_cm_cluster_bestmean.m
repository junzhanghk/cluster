function [stay_avg,stay_ch_avg,chi]=compute_ch_cm_cluster_bestmean(n_v,link_metric,node_metric,n_list,contact_time, stay_time, run_round)


for a_index=1:run_round
for i=1:n_v
order_list(i)=1-node_metric(i);
order_list(i)=order_list(i)*rand();
end
for i=1:n_v
id_list(i)=-node_metric(i);
end
cid_list=ones(n_v,1)*1e5;
[num rank]=sort(order_list);


ch=ones(n_v,1)*-1;
cm=ones(n_v,1)*-1;
assigned=zeros(n_v,1);

stay_all=0;
stay_cnt=0;

for i=1:n_v
    nbi=n_list{i};
    if(id_list(i)<min(id_list(nbi)))
       ch(i)=1;
       cid_list(i)=id_list(i);
    end
end

change_flag=1;
count=0;
while length(find(ch<0&cm<0))>0;
change_flag=0;
count=count+1;
for i=1:n_v
    j=rank(i);
    nbj=n_list{j};
    flag=0;
    for k=1:length(nbj)
       l=nbj(k);
       if(ch(l)==1&&cid_list(l)<cid_list(j))
           if(ch(j)==1)
            change_flag=1;
           end
           if(cm(j)<0)
            ch(j)=-1;
            cm(j)=l;
            cid_list(j)=cid_list(l);
            flag=1;
           end
       end
       if(ch(l)==-1&&cm(l)==-1&&ch(j)==1)
           cm(l)=j;
           cid_list(l)=cid_list(j);
           change_flag=1;
           flag=1;
       end
       if(ch(l)==-1&&ch(j)==1&&cid_list(l)>cid_list(j)&&cm(j)>0)
          cm(l)=j;
          cid_list(l)=cid_list(j);
          change_flag=1;
          flag=1;
       end
    end
    if(flag==0)
        if(ch(j)==-1&&cm(j)==-1)
            empty_list=find(ch(nbj)==-1&cm(nbj)==-1);
            if(id_list(j)<=min(id_list(nbj(empty_list))))
            change_flag=1;            
            ch(j)=1;
            cm(j)=-1;
            cid_list(j)=id_list(j);
            end
            if(isempty(empty_list))
            change_flag=1;            
            ch(j)=1;
            cm(j)=-1;
            cid_list(j)=id_list(j);
            end
        end
    end
end
end

for i=1:n_v
    if(cm(i)<0)
        continue;
    end
    j=cm(i);
    stay_cnt=stay_cnt+1;
    stay_all=stay_all+stay_time(i,j);
end

stay_all2=0;
ch_list=find(ch==1);

for i=1:199
    if(ch(i)<0)
        continue;
    end
    client_list=find(cm==i);
    other_ch=setdiff(ch_list, [i]);
    %ch_dur2 and ch_dur3 reserved for the case of ch mering
    %ch_dur2=min(contact_time(i,other_ch));
    %stay_all2=stay_all2+sum(min(stay_time(i,client_list),ch_dur2));
end

stay_ch_cnt=0;
stay_ch_all=0;
%stay_ch_all2=0;
%stay_ch_all3=0;


for i=1:n_v
    if(ch(i)<0)
        continue;
    end
    memberlist=find(cm==i);
    if(isempty(memberlist))
        continue;
        %ch_dur=t_end-t_start;
    else
        ch_dur=max(stay_time(i,memberlist));
        %cluster head duration is the time for the ch to lose the last cm
    end
    
    other_ch=setdiff(ch_list, [i]);
    %ch_dur2=min(contact_time(i,other_ch));    
    %ch_dur3=min(ch_dur,ch_dur2);
    
    stay_ch_cnt=stay_ch_cnt+1;
    stay_ch_all=stay_ch_all+ch_dur;
    %stay_ch_all2=stay_ch_all2+ch_dur2;
    %stay_ch_all3=stay_ch_all3+ch_dur3;
end

%stay_ch2_avg(a_index)=stay_ch_all2/stay_ch_cnt;
%stay_ch3_avg(a_index)=stay_ch_all3/stay_ch_cnt;
%stay_avg2(a_index)=stay_all2/stay_cnt;

stay_ch_avg(a_index)=stay_ch_all/stay_ch_cnt;
stay_avg(a_index)=stay_all/stay_cnt;

%# of cluster heads
chi(a_index)=length(find(ch>0));

%# of cluster heads (by counting the links from cms to chs)
%chi2(a_index)=length(unique(cm))-1;
end

