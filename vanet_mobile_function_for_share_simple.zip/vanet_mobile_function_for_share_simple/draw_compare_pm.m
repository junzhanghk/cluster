clear;

%Scenario A.1: x200_20_v2
%Scenario A.2: x200_20
%Scenario B.1: x200
%Scenario B.2: x200_v2

load a1_test_all.mat;

%LID
%DEG
%ALM
%VMASC
%LLT
%SF
%SLS

i=1;
cms(i,1)=LID_CM;
cms(i,2)=DEG_CM;
cms(i,3)=RM_CM;
cms(i,4)=VMASC_CM;
cms(i,5)=PS_CM;

cms_std(i,1)=LID_CM_STD;
cms_std(i,2)=DEG_CM_STD;
cms_std(i,3)=RM_CM_STD;
cms_std(i,4)=VMASC_CM_STD;
cms_std(i,5)=PS_CM_STD;

chs(i,1)=LID_CH;
chs(i,2)=DEG_CH;
chs(i,3)=RM_CH;
chs(i,4)=VMASC_CH;
chs(i,5)=PS_CH;

chs_std(i,1)=LID_CH_STD;
chs_std(i,2)=DEG_CH_STD;
chs_std(i,3)=RM_CH_STD;
chs_std(i,4)=VMASC_CH_STD;
chs_std(i,5)=PS_CH_STD;

chi_(i,1)=LID_CHI;
chi_(i,2)=DEG_CHI;
chi_(i,3)=RM_CHI;
chi_(i,4)=VMASC_CHI;
chi_(i,5)=PS_CHI;

chi_std(i,1)=LID_CHI_STD;
chi_std(i,2)=DEG_CHI_STD;
chi_std(i,3)=RM_CHI_STD;
chi_std(i,4)=VMASC_CHI_STD;
chi_std(i,5)=PS_CHI_STD;

load a2_test_all.mat;

i=2;
cms(i,1)=LID_CM;
cms(i,2)=DEG_CM;
cms(i,3)=RM_CM;
cms(i,4)=VMASC_CM;
cms(i,5)=PS_CM;

cms_std(i,1)=LID_CM_STD;
cms_std(i,2)=DEG_CM_STD;
cms_std(i,3)=RM_CM_STD;
cms_std(i,4)=VMASC_CM_STD;
cms_std(i,5)=PS_CM_STD;

chs(i,1)=LID_CH;
chs(i,2)=DEG_CH;
chs(i,3)=RM_CH;
chs(i,4)=VMASC_CH;
chs(i,5)=PS_CH;

chs_std(i,1)=LID_CH_STD;
chs_std(i,2)=DEG_CH_STD;
chs_std(i,3)=RM_CH_STD;
chs_std(i,4)=VMASC_CH_STD;
chs_std(i,5)=PS_CH_STD;

chi_(i,1)=LID_CHI;
chi_(i,2)=DEG_CHI;
chi_(i,3)=RM_CHI;
chi_(i,4)=VMASC_CHI;
chi_(i,5)=PS_CHI;

chi_std(i,1)=LID_CHI_STD;
chi_std(i,2)=DEG_CHI_STD;
chi_std(i,3)=RM_CHI_STD;
chi_std(i,4)=VMASC_CHI_STD;
chi_std(i,5)=PS_CHI_STD;

load b1_test_all.mat;

i=3;
cms(i,1)=LID_CM;
cms(i,2)=DEG_CM;
cms(i,3)=RM_CM;
cms(i,4)=VMASC_CM;
cms(i,5)=PS_CM;

cms_std(i,1)=LID_CM_STD;
cms_std(i,2)=DEG_CM_STD;
cms_std(i,3)=RM_CM_STD;
cms_std(i,4)=VMASC_CM_STD;
cms_std(i,5)=PS_CM_STD;

chs(i,1)=LID_CH;
chs(i,2)=DEG_CH;
chs(i,3)=RM_CH;
chs(i,4)=VMASC_CH;
chs(i,5)=PS_CH;

chs_std(i,1)=LID_CH_STD;
chs_std(i,2)=DEG_CH_STD;
chs_std(i,3)=RM_CH_STD;
chs_std(i,4)=VMASC_CH_STD;
chs_std(i,5)=PS_CH_STD;

chi_(i,1)=LID_CHI;
chi_(i,2)=DEG_CHI;
chi_(i,3)=RM_CHI;
chi_(i,4)=VMASC_CHI;
chi_(i,5)=PS_CHI;

chi_std(i,1)=LID_CHI_STD;
chi_std(i,2)=DEG_CHI_STD;
chi_std(i,3)=RM_CHI_STD;
chi_std(i,4)=VMASC_CHI_STD;
chi_std(i,5)=PS_CHI_STD;




load b2_test_all.mat;


i=4;
cms(i,1)=LID_CM;
cms(i,2)=DEG_CM;
cms(i,3)=RM_CM;
cms(i,4)=VMASC_CM;
cms(i,5)=PS_CM;

cms_std(i,1)=LID_CM_STD;
cms_std(i,2)=DEG_CM_STD;
cms_std(i,3)=RM_CM_STD;
cms_std(i,4)=VMASC_CM_STD;
cms_std(i,5)=PS_CM_STD;

chs(i,1)=LID_CH;
chs(i,2)=DEG_CH;
chs(i,3)=RM_CH;
chs(i,4)=VMASC_CH;
chs(i,5)=PS_CH;

chs_std(i,1)=LID_CH_STD;
chs_std(i,2)=DEG_CH_STD;
chs_std(i,3)=RM_CH_STD;
chs_std(i,4)=VMASC_CH_STD;
chs_std(i,5)=PS_CH_STD;

chi_(i,1)=LID_CHI;
chi_(i,2)=DEG_CHI;
chi_(i,3)=RM_CHI;
chi_(i,4)=VMASC_CHI;
chi_(i,5)=PS_CHI;

chi_std(i,1)=LID_CHI_STD;
chi_std(i,2)=DEG_CHI_STD;
chi_std(i,3)=RM_CHI_STD;
chi_std(i,4)=VMASC_CHI_STD;
chi_std(i,5)=PS_CHI_STD;



index=1:5;





%%%%%%%%%%%%%%%%5
% Defaults for this blog post
width = 3;     % Width in inches
height = 3;    % Height in inches
alw = 0.75;    % AxesLineWidth
fsz = 11;      % Fontsize
lw = 1.5;      % LineWidth
%msz = 8;       % MarkerSize
msz = 6;       % MarkerSize

pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1) pos(2) width*100, height*100]); %<- Set size
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties

% Set Tick Marks
set(gca,'XTick',-3:3);
set(gca,'YTick',0:10);

% Here we preserve the size of the image when we save it.
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
papersize = get(gcf, 'PaperSize');
left = (papersize(1)- width)/2;
bottom = (papersize(2)- height)/2;
myfiguresize = [left, bottom, width, height];
set(gcf,'PaperPosition', myfiguresize);

% Save the file as PNG
% print('improvedExample','-dpng','-r200');
% 
% close all;

% The properties we've been using in the figures
set(0,'defaultLineLineWidth',lw);   % set the default line width to lw
set(0,'defaultLineMarkerSize',msz); % set the default line marker size to msz
set(0,'defaultLineLineWidth',lw);   % set the default line width to lw
set(0,'defaultLineMarkerSize',msz); % set the default line marker size to msz

% Set the default Size for display
defpos = get(0,'defaultFigurePosition');
set(0,'defaultFigurePosition', [defpos(1) defpos(2) width*100, height*100]);

% Set the defaults for saving/printing to a file
set(0,'defaultFigureInvertHardcopy','on'); % This is the default anyway
set(0,'defaultFigurePaperUnits','inches'); % This is the default anyway
defsize = get(gcf, 'PaperSize');
left = (defsize(1)- width)/2;
bottom = (defsize(2)- height)/2;
defsize = [left, bottom, width, height];
set(0, 'defaultFigurePaperPosition', defsize);

%%%%%%%%%%%%%%%%%%%
% figure('name','1:LID_CM');
%  %bar(cms');
%  %hold on;
%  x=0.66:0.14:1.4;
%  bar(cm2s(fl,)');
%  hold on;
%  errorbar(x,cm2s(fl,1)',ch3s_std(fl,1)','r');
%  ylabel('CM duration (Seconds)'); 
%  xlabel('Scenarios'); 
%  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
%  set(gca,'XTickLabel',cases);
% axis([0 5 0 250]);
% legend('LID', 'DEG','ALM', 'LLT','SF','SLS');

%%%%%%

cms=cms';
chs=chs';
chi_=chi_';
cms_std=cms_std';
chs_std=chs_std';
chi_std=chi_std';

%%%%%%%%

fl=index;

figure('name','A1:x200_20_v2 LID_CM');
 %bar(cms');
 %hold on;
 bar(cms(fl,1)');
 hold on;
 errorbar(cms(fl,1)',cms_std(fl,1)','r*');
 ylabel('CM duration (Seconds)'); 
 xlabel('Schemes'); 
%  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 cases=['LID';
     'DEG';
     'ALM';
     'VSC';
     'PM ';
     ];
 set(gca,'XTickLabel',cases);
axis([0 6 0 180]);
%legend('LID', 'DEG','ALM', 'LLT','SF','SLS');


figure('name','A2:x200_20 LID_CM');
 %bar(cms');
 %hold on;
 bar(cms(fl,2)');
 hold on;
 errorbar(cms(fl,2)',cms_std(fl,2)','r*');
 ylabel('CM duration (Seconds)'); 
 xlabel('Schemes'); 
%  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
%  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 cases=['LID';
     'DEG';
     'ALM';
     'VSC';
     'PM ';
     ];
 set(gca,'XTickLabel',cases);
axis([0 6 0 180]);
%legend('LID', 'DEG','ALM', 'LLT','SF','SLS');

figure('name','B1:x200 LID_CM');
 %bar(cms');
 %hold on;
 bar(cms(fl,3)');
 hold on;
 errorbar(cms(fl,3)',cms_std(fl,3)','r*');
 ylabel('CM duration (Seconds)'); 
 xlabel('Schemes'); 
%  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 %  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 cases=['LID';
     'DEG';
     'ALM';
     'VSC';
     'PM ';
     ];
 set(gca,'XTickLabel',cases);
axis([0 6 0 180]);

%legend('LID', 'DEG','ALM', 'LLT','SF','SLS');

figure('name','B2:x200_v2 LID_CM');
 %bar(cms');
 %hold on;
 bar(cms(fl,4)');
 hold on;
 errorbar(cms(fl,4)',cms_std(fl,4)','r*');
 ylabel('CM duration (Seconds)'); 
 xlabel('Schemes'); 
%  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
%  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 cases=['LID';
     'DEG';
     'ALM';
     'VSC';
     'PM ';
     ];
 set(gca,'XTickLabel',cases);
axis([0 6 0 180]);
%legend('LID', 'DEG','ALM', 'LLT','SF','SLS');


figure('name','A1:x200_20_v2 LID_CH');
 %bar(cms');
 %hold on;
 bar(chs(fl,1)');
 hold on;
 errorbar(chs(fl,1)',chs_std(fl,1)','r*');
 ylabel('CH duration (Seconds)'); 
 xlabel('Schemes'); 
%  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 %  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
cases=['LID';
     'DEG';
     'ALM';
     'VSC';
     'PM ';
     ];
 set(gca,'XTickLabel',cases);
axis([0 6 0 200]);
%legend('LID', 'DEG','ALM', 'LLT','SF','SLS');


figure('name','A2:x200_20 LID_CH');
 %bar(cms');
 %hold on;
 bar(chs(fl,2)');
 hold on;
 errorbar(chs(fl,2)',chs_std(fl,2)','r*');
 ylabel('CH duration (Seconds)'); 
 xlabel('Schemes'); 
%  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 %  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 cases=['LID';
     'DEG';
     'ALM';
     'VSC';
     'PM ';
     ];
 set(gca,'XTickLabel',cases);
axis([0 6 0 200]);
%legend('LID', 'DEG','ALM', 'LLT','SF','SLS');

figure('name','B1:x200 LID_CH');
 %bar(cms');
 %hold on;
 bar(chs(fl,3)');
 hold on;
 errorbar(chs(fl,3)',chs_std(fl,3)','r*');
 ylabel('CH duration (Seconds)'); 
 xlabel('Schemes'); 
%  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
  %  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 cases=['LID';
     'DEG';
     'ALM';
     'VSC';
     'PM ';
     ];
 set(gca,'XTickLabel',cases);
axis([0 6 0 200]);
%legend('LID', 'DEG','ALM', 'LLT','SF','SLS');

figure('name','B2:x200_v2 LID_CH');
 %bar(cms');
 %hold on;
 bar(chs(fl,4)');
 hold on;
 errorbar(chs(fl,4)',chs_std(fl,4)','r*');
 ylabel('CH duration (Seconds)'); 
 xlabel('Schemes'); 
%  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
  %  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 cases=['LID';
     'DEG';
     'ALM';
     'VSC';
     'PM ';
     ];
 set(gca,'XTickLabel',cases);
axis([0 6 0 200]);
%legend('LID', 'DEG','ALM', 'LLT','SF','SLS');

figure('name','A1:x200_20_v2 LID_cluster');
 %bar(cms');
 %hold on;
 bar(chi_(fl,1)');
 hold on;
 errorbar(chi_(fl,1)',chi_std(fl,1)','r*');
 ylabel('Number of clusters'); 
 xlabel('Schemes'); 
%  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
  %  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 cases=['LID';
     'DEG';
     'ALM';
     'VSC';
     'PM ';
     ];
 set(gca,'XTickLabel',cases);
axis([0 6 0 50]);
%legend('LID', 'DEG','ALM', 'LLT','SF','SLS');


figure('name','A2:x200_20 LID_Cluster');
 %bar(cms');
 %hold on;
 bar(chi_(fl,2)');
 hold on;
 errorbar(chi_(fl,2)',chi_std(fl,2)','r*');
 ylabel('CM duration (Seconds)'); 
 xlabel('Schemes'); 
%  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 %  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 cases=['LID';
     'DEG';
     'ALM';
     'VSC';
     'PM ';
     ];
 set(gca,'XTickLabel',cases);
axis([0 6 0 50]);
%legend('LID', 'DEG','ALM', 'LLT','SF','SLS');

figure('name','B1:x200 LID_Cluster');
 %bar(cms');
 %hold on;
 bar(chi_(fl,3)');
 hold on;
 errorbar(chi_(fl,3)',chi_std(fl,3)','r*');
 ylabel('Number of clusters'); 
 xlabel('Schemes'); 
%  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 %  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 cases=['LID';
     'DEG';
     'ALM';
     'VSC';
     'PM ';
     ];
 set(gca,'XTickLabel',cases);
axis([0 6 0 50]);
%legend('LID', 'DEG','ALM', 'LLT','SF','SLS');

figure('name','B2:x200_v2 LID_ cluster');
 %bar(cms');
 %hold on;
 bar(chi_(fl,4)');
 hold on;
 errorbar(chi_(fl,4)',chi_std(fl,4)','r*');
 ylabel('Number of clusters'); 
 xlabel('Schemes'); 
%  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 %  cases=['A.1';
%      'A.2';
%      'B.1';
%      'B.2'];
 cases=['LID';
     'DEG';
     'ALM';
     'VSC';
     'PM ';
     ];
 set(gca,'XTickLabel',cases);
axis([0 6 0 50]);
%legend('LID', 'DEG','ALM', 'LLT','SF','SLS'); 