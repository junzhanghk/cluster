function [speed, v_d, loc, v_mean, dist, DIST]=get_scenario_info(X200,t_start,t_end, t_left, t_right, t_total, n_v, dist_middle, t_inter)
%return values
%speed(i,t): speed (with direction) of node i
%v_d(i): direction of i 
%loc(i,t): location of i at time t
%v_mean(i,t): mean speed of i between time t-t_inter 
%dist(i,j,t): distance between i and j at time t
%DIST(i,j): sum of distance difference between i and j at period between t_start and t_end 

index1=find(X200(:,2)==1);
index3=find(X200(:,2)==3);
index_file=cell(n_v,1);

%t_start=350;
%t_end=550;
%t_right=600;
%t_left=150;
%n_v=199;
%dist_middle=5000;
%t_inter=10;

for i=1:n_v
 index_file{i}=find(X200(:,2)==i-1&X200(:,1)>=t_left&X200(:,1)<=t_end);
end




for i=1:n_v
    indexi=index_file{i};
    speed(i,1:t_total)=zeros(t_total,1);   
    if(X200(indexi(1),3)<dist_middle) %check_direction
      loc(i,1:t_total)=zeros(t_total,1);
      loc(i,t_left:length(indexi)+t_left-1)=X200(indexi,3);
      speed(i,t_left:length(indexi)+t_left-1)=X200(indexi,5);
      v_d(i)=1;
    else
       loc(i,1:t_total)=ones(t_total,1)*1e4; 
       speed(i,t_left:length(indexi)+t_left-1)=-X200(indexi,5);
       loc(i,t_left:length(indexi)+t_left-1)=X200(indexi,3);
       v_d(i)=-1;
    end
end


v_mean=zeros(n_v,t_total);
for i=1:n_v
   for t=1+t_inter:t_total
    v_mean(i,t)=(loc(i,t)-loc(i,t-t_inter))/t_inter;
   end
end


for i=1:n_v
    for j=1:n_v
      for t=t_left:t_end
         dist(i,j,t)=loc(i,t)-loc(j,t); 
      end
    end
end



for i=1:n_v
    for j=1:n_v
         DIST(i,j)=sum(abs(dist(i,j,t_start:t_end))); 
    end
end