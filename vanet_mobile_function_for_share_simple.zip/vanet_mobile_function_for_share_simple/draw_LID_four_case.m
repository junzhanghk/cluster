clear;

%Scenario A.1: x200_20_v2
%Scenario A.2: x200_20
%Scenario B.1: x200
%Scenario B.2: x200_v2

%case1.1 Lowest ID, with direction, random id   (RND,SAME)
%case1.2 Lowest ID, no direction, random id     (RND,ALL)
%case1.3 Lowest ID, with direction, id=default id (VID,SAME)
%case1.4 Lowest ID, no direction, id=default id (VID,ALL)


load a1_test.mat;

for i=1:4
x200_20_v2(1,i)=LID_CM(i);
x200_20_v2(2,i)=LID_CH(i);
x200_20_v2(3,i)=LID_CHI(i);
end

load a2_test.mat;

for i=1:4
x200_20(1,i)=LID_CM(i);
x200_20(2,i)=LID_CH(i);
x200_20(3,i)=LID_CHI(i);
end

load b1_test.mat;

for i=1:4
x200(1,i)=LID_CM(i);
x200(2,i)=LID_CH(i);
x200(3,i)=LID_CHI(i);
end

load b2_test.mat;

for i=1:4
x200_v2(1,i)=LID_CM(i);
x200_v2(2,i)=LID_CH(i);
x200_v2(3,i)=LID_CHI(i);
end

cm=zeros(3,4);
ch=zeros(3,4);
chi=zeros(3,4);

% x200=[99.50516001	89.39052955	93.87	72.6181
% 146.577152	148.296537	147.03	129.3388
% 32.09	25.12	31.93	25.28];
% 
% x200_20=[118.9936442	76.52294391	95.0618	37.7231
% 160.559414	149.4794729	150.1185	120.2972
% 39.35	26.69	39.66	25.6];
% 
% x200_v2=[89.36474846	70.83802314	72.2142	38.5992
% 141.9607391	131.8879603	137.3725	105.9119
% 36.92	26.95	36.93	26];
% 
% x200_20_v2=[132.4354516	79.81235078	120.652	44.6966
% 170.2707882	162.0321903	177.1203	184.8901
% 25.37	13.78	25.83	13.72];


cm(1,:)=x200_20_v2(1,:);
cm(2,:)=x200_20(1,:);
cm(3,:)=x200(1,:);
cm(4,:)=x200_v2(1,:);

ch(1,:)=x200_20_v2(2,:);
ch(2,:)=x200_20(2,:);
ch(3,:)=x200(2,:);
ch(4,:)=x200_v2(2,:);

chi(1,:)=x200_20_v2(3,:);
chi(2,:)=x200_20(3,:);
chi(3,:)=x200(3,:);
chi(4,:)=x200_v2(3,:);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
% draw
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

 figure('name','1:LID_CM');
 bar(cm);
 ylabel('CM duration (Seconds)'); 
 xlabel('Scenarios'); 
 cases=['A.1';
     'A.2';
     'B.1';
     'B.2'];
 set(gca,'XTickLabel',cases);
axis([0 5 0 200]);
legend('LID (RND, SAME)', 'LID(RND, ALL)','LID(VID, SAME)', 'LID(VID, ALL)');

 figure('name','1:LID_CH');
 bar(ch);
 ylabel('CH duration (Seconds)'); 
 xlabel('Scenarios'); 
 cases=['A.1';
     'A.2';
     'B.1';
     'B.2'];
 set(gca,'XTickLabel',cases);
axis([0 5 0 250]);
legend('LID(RND, SAME)', 'LID(RND, ALL)','LID(VID, SAME)', 'LID(VID, ALL)');

 figure('name','1:LID_CHI');
 bar(chi);
 ylabel('Number of clusters'); 
 xlabel('Scenarios'); 
 cases=['A.1';
     'A.2';
     'B.1';
     'B.2'];
 set(gca,'XTickLabel',cases);
axis([0 5 0 70]);
legend('LID (RND, SAME)', 'LID(RND, ALL)','LID(VID, SAME)', 'LID(VID, ALL)');



