function [link_metric, node_metric]=llt_metric(n_v,dist,speed,loc,vd,max_dist,t_start,t_end,n_list)


for i=1:n_v
    for j=1:n_v
       if(abs(dist(i,j,t_start))>=max_dist)
           LLTI(i,j)=0;
       else
       vd=speed(i,t_start)-speed(j,t_start);
       ld=dist(i,j,t_start);
       LLTI(i,j)= min((max_dist*abs(vd)-ld*vd)/(vd^2),max_dist);
       end
end
end

for i=1:n_v
    if(isempty(n_list{i}))
        LLT(i)=0;
    else
    LLT(i)=mean(LLTI(i,n_list{i}));
    end
end

link_metric=LLTI;
node_metric=LLT;