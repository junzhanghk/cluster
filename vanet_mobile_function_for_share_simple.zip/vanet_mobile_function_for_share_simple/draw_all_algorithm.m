clear;

load a1_test_all.mat;

%LID
%DEG
%ALM
%VMASC
%LLT
%SF
%SLS

cms(1,1)=LID_CM;
cms(1,2)=DEG_CM;
cms(1,3)=RM_CM;
cms(1,4)=VMASC_CM;
cms(1,5)=LLT_CM;
cms(1,6)=SF_CM;
cms(1,7)=SLS_CM;



chs(1,1)=LID_CH;
chs(1,2)=DEG_CH;
chs(1,3)=RM_CH;
chs(1,4)=VMASC_CH;
chs(1,5)=LLT_CH;
chs(1,6)=SF_CH;
chs(1,7)=SLS_CH;

chi_(1,1)=LID_CHI;
chi_(1,2)=DEG_CHI;
chi_(1,3)=RM_CHI;
chi_(1,4)=VMASC_CHI;
chi_(1,5)=LLT_CHI;
chi_(1,6)=SF_CHI;
chi_(1,7)=SLS_CHI;

load a2_test_all.mat;

cms(2,1)=LID_CM;
cms(2,2)=DEG_CM;
cms(2,3)=RM_CM;
cms(2,4)=VMASC_CM;
cms(2,5)=LLT_CM;
cms(2,6)=SF_CM;
cms(2,7)=SLS_CM;


chs(2,1)=LID_CH;
chs(2,2)=DEG_CH;
chs(2,3)=RM_CH;
chs(2,4)=VMASC_CH;
chs(2,5)=LLT_CH;
chs(2,6)=SF_CH;
chs(2,7)=SLS_CH;

chi_(2,1)=LID_CHI;
chi_(2,2)=DEG_CHI;
chi_(2,3)=RM_CHI;
chi_(2,4)=VMASC_CHI;
chi_(2,5)=LLT_CHI;
chi_(2,6)=SF_CHI;
chi_(2,7)=SLS_CHI;


load b1_test_all.mat;

cms(3,1)=LID_CM;
cms(3,2)=DEG_CM;
cms(3,3)=RM_CM;
cms(3,4)=VMASC_CM;
cms(3,5)=LLT_CM;
cms(3,6)=SF_CM;
cms(3,7)=SLS_CM;


chs(3,1)=LID_CH;
chs(3,2)=DEG_CH;
chs(3,3)=RM_CH;
chs(3,4)=VMASC_CH;
chs(3,5)=LLT_CH;
chs(3,6)=SF_CH;
chs(3,7)=SLS_CH;


chi_(3,1)=LID_CHI;
chi_(3,2)=DEG_CHI;
chi_(3,3)=RM_CHI;
chi_(3,4)=VMASC_CHI;
chi_(3,5)=LLT_CHI;
chi_(3,6)=SF_CHI;
chi_(3,7)=SLS_CHI;



load b2_test_all.mat;


cms(4,1)=LID_CM;
cms(4,2)=DEG_CM;
cms(4,3)=RM_CM;
cms(4,4)=VMASC_CM;
cms(4,5)=LLT_CM;
cms(4,6)=SF_CM;
cms(4,7)=SLS_CM;



chs(4,1)=LID_CH;
chs(4,2)=DEG_CH;
chs(4,3)=RM_CH;
chs(4,4)=VMASC_CH;
chs(4,5)=LLT_CH;
chs(4,6)=SF_CH;
chs(4,7)=SLS_CH;


chi_(4,1)=LID_CHI;
chi_(4,2)=DEG_CHI;
chi_(4,3)=RM_CHI;
chi_(4,4)=VMASC_CHI;
chi_(4,5)=LLT_CHI;
chi_(4,6)=SF_CHI;
chi_(4,7)=SLS_CHI;



index=1:7;

%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%5
% Defaults for this blog post
width = 3;     % Width in inches
height = 3;    % Height in inches
alw = 0.75;    % AxesLineWidth
fsz = 11;      % Fontsize
lw = 1.5;      % LineWidth
%msz = 8;       % MarkerSize
msz = 6;       % MarkerSize

pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1) pos(2) width*100, height*100]); %<- Set size
set(gca, 'FontSize', fsz, 'LineWidth', alw); %<- Set properties

% Set Tick Marks
set(gca,'XTick',-3:3);
set(gca,'YTick',0:10);

% Here we preserve the size of the image when we save it.
set(gcf,'InvertHardcopy','on');
set(gcf,'PaperUnits', 'inches');
papersize = get(gcf, 'PaperSize');
left = (papersize(1)- width)/2;
bottom = (papersize(2)- height)/2;
myfiguresize = [left, bottom, width, height];
set(gcf,'PaperPosition', myfiguresize);

% Save the file as PNG
% print('improvedExample','-dpng','-r200');
% 
% close all;

% The properties we've been using in the figures
set(0,'defaultLineLineWidth',lw);   % set the default line width to lw
set(0,'defaultLineMarkerSize',msz); % set the default line marker size to msz
set(0,'defaultLineLineWidth',lw);   % set the default line width to lw
set(0,'defaultLineMarkerSize',msz); % set the default line marker size to msz

% Set the default Size for display
defpos = get(0,'defaultFigurePosition');
set(0,'defaultFigurePosition', [defpos(1) defpos(2) width*100, height*100]);

% Set the defaults for saving/printing to a file
set(0,'defaultFigureInvertHardcopy','on'); % This is the default anyway
set(0,'defaultFigurePaperUnits','inches'); % This is the default anyway
defsize = get(gcf, 'PaperSize');
left = (defsize(1)- width)/2;
bottom = (defsize(2)- height)/2;
defsize = [left, bottom, width, height];
set(0, 'defaultFigurePaperPosition', defsize);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
% draw
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

 figure('name','1:LID_CM');
 bar(cms(:,index));
 ylabel('CM duration (Seconds)'); 
 xlabel('Scenarios'); 
 cases=['A.1';
     'A.2';
     'B.1';
     'B.2'];
 set(gca,'XTickLabel',cases);
axis([0 5 60 180]);
legend('LID', 'GRE','ALM', 'VSC','LLT','SF','SLS');

 figure('name','2:LID_CH');
 bar(chs(:,index));
 ylabel('CH duration (Seconds)'); 
 xlabel('Scenarios'); 
 cases=['A.1';
     'A.2';
     'B.1';
     'B.2'];
 set(gca,'XTickLabel',cases);
axis([0 5 100 200]);
legend('LID', 'GRE','ALM', 'VSC','LLT','SF','SLS');

 figure('name','3:LID_CLUSTER');
 bar(chi_(:,index));
 ylabel('Number of clusters'); 
 xlabel('Scenarios'); 
 cases=['A.1';
     'A.2';
     'B.1';
     'B.2'];
 set(gca,'XTickLabel',cases);
axis([0 5 0 50]);
legend('LID', 'GRE','ALM', 'VSC','LLT','SF','SLS');

