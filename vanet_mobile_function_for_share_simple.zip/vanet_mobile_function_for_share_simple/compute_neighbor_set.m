function [nb_list,nb_list_r,nb_list_a,stay_time, contact_time]=compute_neighbor_set(t_start,t_end,n_v,dist,v_d,speed,max_dist,speed_range)
%return
%stay_time(i,j): connection time between i and j from t_start
%nb_list: neighbors in the same direction
%nb_list_r: neighbors in the reverse direction
%nb_list_a: all neighbors
%speed_range: limit for the speed difference between neighbors
%max_dist: limit for the distance between neighbors


for i=1:n_v
    for j=1:n_v
         if(abs(dist(i,j,t_start))>max_dist)
          stay_time(i,j)=0;
         else
         % if(speed(i,t_start)*speed(j,t_start)<0) 
         %  stay_time(i,j)=0;
         % else 
            [st_index]=min(find(abs(dist(i,j,t_start:t_end))>max_dist));
            if(isempty(st_index))
                stay_time(i,j)=t_end-t_start;
            else
                stay_time(i,j)=st_index-1;
            end
          %end
         end
    end
end


for i=1:n_v
    for j=1:n_v
         if(abs(dist(i,j,t_start))<max_dist)
          contact_time(i,j)=0;
         else
         % if(speed(i,t_start)*speed(j,t_start)<0) 
         %  stay_time(i,j)=0;
         % else 
            [st_index]=min(find(abs(dist(i,j,t_start:t_end))<max_dist));
            if(isempty(st_index))
                contact_time(i,j)=t_end-t_start;
            else
                contact_time(i,j)=st_index-1;
            end
          %end
         end
    end
end


for i=1:n_v
    for j=1:n_v
         if(abs(dist(i,j,t_start))<max_dist&&v_d(i)*v_d(j)>1)
          contact_time_d(i,j)=0;
         elseif(v_d(i)*v_d(j)<0)
          contact_time_d(i,j)=t_end-t_start;   
         else
         % if(speed(i,t_start)*speed(j,t_start)<0) 
         %  stay_time(i,j)=0;
         % else 
            [st_index]=min(find(abs(dist(i,j,t_start:t_end))<max_dist));
            if(isempty(st_index))
                contact_time_d(i,j)=t_end-t_start;
            else
                contact_time_d(i,j)=st_index-1;
            end
          %end
         end
    end
end

nb=zeros(n_v,n_v);
nb_a=zeros(n_v,n_v);
nb_r=zeros(n_v,n_v);
for i=1:n_v
    for j=1:n_v
    if(abs(dist(i,j,t_start))<max_dist&&speed(i,t_start)*speed(j,t_start)>=0&&abs(speed(i,t_start)-speed(j,t_start))<speed_range)
          nb(i,j)=1; %neighbors moving in the same range
    end
    if(abs(dist(i,j,t_start))<max_dist&&speed(i,t_start)*speed(j,t_start)<0&&abs(speed(i,t_start)-speed(j,t_start))<speed_range)
          nb_r(i,j)=1; %neighbors move in the reverse range
    end
    if(abs(dist(i,j,t_start))<max_dist&&abs(speed(i,t_start)-speed(j,t_start))<speed_range)
          nb_a(i,j)=1; %all neighbors
    end
    
        end
    nb_list{i}=setdiff(find(nb(i,:)),[i]);
    nb_list_a{i}=setdiff(find(nb_a(i,:)),[i]);
    nb_list_r{i}=setdiff(find(nb_r(i,:)),[i]);
end