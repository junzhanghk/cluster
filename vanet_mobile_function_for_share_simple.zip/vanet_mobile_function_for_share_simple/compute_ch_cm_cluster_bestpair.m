function [stay_avg,stay_ch_avg,chi]=compute_ch_cm_cluster_bestpair(n_v,link_metric,node_metric,n_list,contact_time, stay_time, run_round)


for a_index=1:run_round
for i=1:n_v
order_list(i)=rand();
end
for i=1:n_v
id_list(i)=-node_metric(i);
end
cid_list=ones(n_v,1)*2;
[num rank]=sort(order_list);


ch=ones(n_v,1)*-1;
cm=ones(n_v,1)*-1;
assigned=zeros(n_v,1);

stay_all=0;
stay_cnt=0;

for i=1:n_v
    nbi=n_list{i};
    if(id_list(i)<min(id_list(nbi)))
       ch(i)=1;
       cid_list(i)=id_list(i);
    end
end

change_flag=1;
count=0;
while length(find(ch<0&cm<0))>0
change_flag=0;
count=count+1;
for i=1:n_v
    j=rank(i);
    nbj=n_list{j};
    if(cm(j)==-1&&ch(j)==-1)
     ttt=1;
    end
    flag=0;
    for k=1:length(nbj)
       l=nbj(k);
       if(ch(l)==1&&ch(j)==1&&node_metric(l)>node_metric(j))
          change_flag=1;
          ch(j)=-1;
          cm(j)=l;
          cid_list(j)=link_metric(j,l);
          flag=1;
       end
       if(ch(l)==1&&ch(j)==-1&&cm(j)<0)
            ch(j)=-1;
            cm(j)=l;
            cid_list(j)=-node_metric(l);
            change_flag=1;
            flag=1;
       end
       if(ch(l)==1&&ch(j)==-1&&cm(j)>0&&cid_list(j)<link_metric(j,l))
            ch(j)=-1;
            cm(j)=l;
            cid_list(j)=link_metric(j,l);
            change_flag=1;
            flag=1;
       end
       if(ch(l)==-1&&cm(l)==-1&&ch(j)==1)
           cm(l)=j;
           cid_list(l)=link_metric(j,l);
           change_flag=1;
           flag=1;
       end
       if(ch(l)==-1&&ch(j)==1&&cid_list(l)<link_metric(j,l)&&cm(l)>0)
          cm(l)=j;
          cid_list(l)=link_metric(j,l);
          change_flag=1;
          flag=1;
       end
    end
    if(flag==0)
        if(ch(j)==-1&&cm(j)==-1)
            empty_list=find(ch(nbj)==-1&cm(nbj)==-1);
            if(id_list(j)<=min(id_list(nbj(empty_list))))
            change_flag=1;            
            ch(j)=1;
            cm(j)=-1;
            cid_list(j)=id_list(j);
            end
            if(isempty(empty_list))
            change_flag=1;            
            ch(j)=1;
            cm(j)=-1;
            cid_list(j)=id_list(j);
            end
        end
    end
end
end

for i=1:n_v
    if(cm(i)<0)
        continue;
    end
    j=cm(i);
    stay_cnt=stay_cnt+1;
    stay_all=stay_all+stay_time(i,j);
end

stay_ch_cnt=0;
stay_ch_all=0;

for i=1:n_v
    if(ch(i)<0)
        continue;
    end
    memberlist=find(cm==i);
    if(isempty(memberlist))
        continue;
        ch_dur=t_end-t_start;
    else
        ch_dur=max(stay_time(i,memberlist));
    end    
    stay_ch_cnt=stay_ch_cnt+1;
    stay_ch_all=stay_ch_all+ch_dur;
end

stay_ch_avg(a_index)=stay_ch_all/stay_ch_cnt;
stay_avg(a_index)=stay_all/stay_cnt;
chi(a_index)=length(find(ch>0));
%chi2_PS(a_index)=length(unique(cm))-1;
end

