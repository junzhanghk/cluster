clear;

%step1. load scenario


%Scenario A.1
%load X200_20_v2.mat;
%X200=X200_20_v2;
%savename='a1_test_all.mat';

%Scenario A.2
%load X200_20.mat;
%X200=X200_20;
%savename='a2_test_all.mat';

%Scenario B.1
%load X200.mat;
%savename='b1_test_all.mat';

%Scenario B.2
load X200_v2.mat;
X200=X200_v2;
savename='b2_test_all.mat';

%each entry in X200 contains time, ID, X, Y, |speed|

%step 2. compute information
%return values
%speed(i,t): speed (with direction) of node i
%v_d(i): direction of i 
%loc(i,t): location of i at time t
%v_mean(i,t): mean speed of i between time t-t_inter 
%dist(i,j,t): distance between i and j at time t
%DIST(i,j): sum of distance difference between i and j at period between t_start and t_end 

t_start=350;
t_end=550;
t_left=150;
t_right=600;
t_total=600;
t_inter=10;
n_v=200;
dist_middle=5000;

[speed, v_d, loc, v_mean, dist, DIST]=get_scenario_info(X200,t_start,t_end, t_left, t_right, t_total, n_v, dist_middle, t_inter);

%3. compute neighborhood
speed_range=100;%no limit of speed difference between neighbors
max_dist=200; %safe transmission range between neighbors
[nb_list,nb_list_r,nb_list_a,stay_time, contact_time]=compute_neighbor_set(t_start,t_end,n_v,dist,v_d,speed,max_dist,speed_range);

%stay_time(i,j): connection time between i and j from t_start
%nb_list{i}: neighbors of node i in the same direction
%nb_list_r{i}: neighbors of node i in the reverse direction
%nb_list_a{i}: all neighbors of node i
%speed_range: limit for the speed difference between neighbors
%max_dist: limit for the distance between neighbors
%contact_time(i,j): the minimal time that two chs i, j meet from t_start
%%4. compute metrics

%4.a: relative mobility: RM(link metric), ALM(node metric)

%same direction
[RM, ALM]=rm_metric(n_v,dist,speed,loc,v_d,max_dist,t_start,t_end,nb_list);
%reverse direction
[RM_r, ALM_r]=rm_metric(n_v,dist,speed,loc,v_d,max_dist,t_start,t_end,nb_list_r);
%all direction
[RM_a, ALM_a]=rm_metric(n_v,dist,speed,loc,v_d,max_dist,t_start,t_end,nb_list_a);

%4.b degree
%same direction
DEG=degree_metric(n_v,dist,speed,loc,v_d,max_dist,t_start,t_end,nb_list);
%reverse direction
DEG_r=degree_metric(n_v,dist,speed,loc,v_d,max_dist,t_start,t_end,nb_list_r);
%all direction
DEG_a=degree_metric(n_v,dist,speed,loc,v_d,max_dist,t_start,t_end,nb_list_a);

%4.c: LLTI(link metric), LLT(node metric)
%same direction
[LLTI, LLT]=llt_metric(n_v,dist,speed,loc,v_d,max_dist,t_start,t_end,nb_list);
%reverse direction
[LLTI_r, LLT_r]=llt_metric(n_v,dist,speed,loc,v_d,max_dist,t_start,t_end,nb_list_r);
%all direction
[LLTI_a, LLT_a]=llt_metric(n_v,dist,speed,loc,v_d,max_dist,t_start,t_end,nb_list_a);


%4.c.2: LLTA(link metric), LLTA_(node metric)
%same direction
[LLTA, LLTA_]=llt_metric(n_v,dist,v_mean,loc,v_d,max_dist,t_start,t_end,nb_list);
%reverse direction
[LLTA_r, LLTA_r]=llt_metric(n_v,dist,v_mean,loc,v_d,max_dist,t_start,t_end,nb_list_r);
%all direction
[LLTA_a, LLTA_a]=llt_metric(n_v,dist,v_mean,loc,v_d,max_dist,t_start,t_end,nb_list_a);

%4.d: SLSI(link metric), SLS(node metric)
%same direction
[SLSI, SLS]=sls_metric(n_v,dist,speed,loc,v_d,max_dist,t_start,t_end,nb_list);
%reverse direction
[SLSI_r, SLS_r]=sls_metric(n_v,dist,speed,loc,v_d,max_dist,t_start,t_end,nb_list_r);
%all direction
[SLSI_a, SLS_a]=sls_metric(n_v,dist,speed,loc,v_d,max_dist,t_start,t_end,nb_list_a);

%4.d.2: SLSA, SLSA_
%same direction
[SLSA, SLA_]=sls_metric(n_v,dist,v_mean,loc,v_d,max_dist,t_start,t_end,nb_list);
%reverse direction
[SLSA_r, SLA_r]=sls_metric(n_v,dist,v_mean,loc,v_d,max_dist,t_start,t_end,nb_list_r);
%all direction
[SLSA_a, SLA_a]=sls_metric(n_v,dist,v_mean,loc,v_d,max_dist,t_start,t_end,nb_list_a);

%4.e SFI(link metric), SF(node metric)
%same direction
[SFI, SF]=sf_metric(n_v,dist,speed,loc,v_d,max_dist,t_start,t_end,nb_list);
%reverse direction
[SFI_r, SF_r]=sf_metric(n_v,dist,speed,loc,v_d,max_dist,t_start,t_end,nb_list_r);
%all direction
[SF_a, SF_a]=sf_metric(n_v,dist,speed,loc,v_d,max_dist,t_start,t_end,nb_list_a);

%4.e.2 SFA(link metric), SFA_(node metric)
%same direction
[SFA, SFA_]=sf_metric(n_v,dist,v_mean,loc,v_d,max_dist,t_start,t_end,nb_list);
%reverse direction
[SFA_r, SFA_r]=sf_metric(n_v,dist,v_mean,loc,v_d,max_dist,t_start,t_end,nb_list_r);
%all direction
[SFA_a, SFA_a]=sf_metric(n_v,dist,v_mean,loc,v_d,max_dist,t_start,t_end,nb_list_a);

%4.f diffv(link metric), vmasc(node metric);
%same direction
[DIFFV, VMASC]=vmasc_metric(n_v,speed,t_start,nb_list);
%reverse direction
[DIFFV_r, VMASC_r]=vmasc_metric(n_v,speed,t_start,nb_list_r);
%all direction
[DIFFV_a, VMASC_a]=vmasc_metric(n_v,speed,t_start,nb_list_a);


%4.g PSI(link metric), PS(node metric)
%same direction
[PSI, PS]=ps_metric(n_v,stay_time,nb_list);
%reverse direction
[PSI_r, PS_r]=ps_metric(n_v,stay_time,nb_list_r);
%all direction
[PSI_a, PS_a]=ps_metric(n_v,stay_time,nb_list_a);

%LID cm ch cluster

%LID CM CH CLUSTER

%case1.1 Lowest ID, with direction, random id

run_round=100;

for run=1:run_round
rnd_node_metric=rand(n_v,1);
rnd_link_metric=rand(n_v,n_v);
[stay_avg,stay_ch_avg,chi]=compute_ch_cm_cluster_bestmean(n_v,rnd_link_metric,rnd_node_metric,nb_list,contact_time, stay_time, 1);

LID_CM_run(run)=mean(stay_avg);
LID_CH_run(run)=mean(stay_ch_avg);
LID_CHI_run(run)=mean(chi);

LID_CM_STD_run(run)=std(stay_avg);
LID_CH_STD_run(run)=std(stay_ch_avg);
LID_CHI_STD_run(run)=std(chi);

end

LID_CM=mean(LID_CM_run);
LID_CH=mean(LID_CH_run);
LID_CHI=mean(LID_CHI_run);

LID_CM_STD=std(LID_CM_run);
LID_CH_STD=std(LID_CH_run);
LID_CHI_STD=std(LID_CHI_run);







%7. testing







%%: compare between algs
%degree 
rnd_link_metric=rand(n_v,n_v);
[stay_avg,stay_ch_avg,chi]=compute_ch_cm_cluster_bestmean(n_v,rnd_link_metric,DEG,nb_list,contact_time, stay_time, run_round);


DEG_CM=mean(stay_avg);
DEG_CH=mean(stay_ch_avg);
DEG_CHI=mean(chi);

DEG_CM_STD=std(stay_avg);
DEG_CH_STD=std(stay_ch_avg);
DEG_CHI_STD=std(chi);

[stay_avg,stay_ch_avg,chi]=compute_ch_cm_cluster_bestmean(n_v,RM,ALM,nb_list,contact_time, stay_time, run_round);

RM_CM=mean(stay_avg);
RM_CH=mean(stay_ch_avg);
RM_CHI=mean(chi);

RM_CM_STD=std(stay_avg);
RM_CH_STD=std(stay_ch_avg);
RM_CHI_STD=std(chi);

[stay_avg,stay_ch_avg,chi]=compute_ch_cm_cluster_bestmean(n_v,LLTI,LLT,nb_list,contact_time, stay_time, run_round);

LLT_CM=mean(stay_avg);
LLT_CH=mean(stay_ch_avg);
LLT_CHI=mean(chi);

LLT_CM_STD=std(stay_avg);
LLT_CH_STD=std(stay_ch_avg);
LLT_CHI_STD=std(chi);

[stay_avg,stay_ch_avg,chi]=compute_ch_cm_cluster_bestmean(n_v,LLTA,LLTA_,nb_list,contact_time, stay_time, run_round);

LLTA_CM=mean(stay_avg);
LLTA_CH=mean(stay_ch_avg);
LLTA_CHI=mean(chi);

LLTA_CM_STD=std(stay_avg);
LLTA_CH_STD=std(stay_ch_avg);
LLTA_CHI_STD=std(chi);

[stay_avg,stay_ch_avg,chi]=compute_ch_cm_cluster_bestmean(n_v,SLSI,SLS,nb_list,contact_time, stay_time, run_round);

SLS_CM=mean(stay_avg);
SLS_CH=mean(stay_ch_avg);
SLS_CHI=mean(chi);

SLS_CM_STD=std(stay_avg);
SLS_CH_STD=std(stay_ch_avg);
SLS_CHI_STD=std(chi);

[stay_avg,stay_ch_avg,chi]=compute_ch_cm_cluster_bestmean(n_v,SFI,SF,nb_list,contact_time, stay_time, run_round);

SF_CM=mean(stay_avg);
SF_CH=mean(stay_ch_avg);
SF_CHI=mean(chi);

SF_CM_STD=std(stay_avg);
SF_CH_STD=std(stay_ch_avg);
SF_CHI_STD=std(chi);

[stay_avg,stay_ch_avg,chi]=compute_ch_cm_cluster_bestmean(n_v,DIFFV,VMASC,nb_list,contact_time, stay_time, run_round);

VMASC_CM=mean(stay_avg);
VMASC_CH=mean(stay_ch_avg);
VMASC_CHI=mean(chi);

VMASC_CM_STD=std(stay_avg);
VMASC_CH_STD=std(stay_ch_avg);
VMASC_CHI_STD=std(chi);

[stay_avg,stay_ch_avg,chi]=compute_ch_cm_cluster_bestmean(n_v,PSI,PS,nb_list,contact_time, stay_time, run_round);

PS_CM=mean(stay_avg);
PS_CH=mean(stay_ch_avg);
PS_CHI=mean(chi);

PS_CM_STD=std(stay_avg);
PS_CH_STD=std(stay_ch_avg);
PS_CHI_STD=std(chi);

 
save(savename);