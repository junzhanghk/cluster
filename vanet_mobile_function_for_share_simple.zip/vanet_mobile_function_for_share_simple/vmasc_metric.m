function [link_metric, node_metric]=vmasc_metric(n_v,speed,t_start,n_list)

for i=1:n_v
    for j=1:n_v
       DIFFV(i,j)=-abs(speed(i,t_start)-speed(j,t_start));
end
end

for i=1:n_v
    if(isempty(n_list{i}))
        MSC(i)=0;
    else
    MSC(i)=mean(DIFFV(i,n_list{i}));
    end
end

link_metric=DIFFV;
node_metric=MSC;