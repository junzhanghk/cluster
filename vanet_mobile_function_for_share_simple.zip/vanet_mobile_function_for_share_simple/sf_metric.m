function [link_metric, node_metric]=sf_metric(n_v,dist,speed,loc,vd,max_dist,t_start,t_end,n_list)

pre_t=10; %s

for i=1:n_v
    for j=1:n_v
        SFI(i,j)=-abs(dist(i,j,t_start))-abs(loc(i,t_start)+speed(i,t_start)*pre_t-loc(j,t_start)-speed(j,t_start)*pre_t);
       
end
end



for i=1:n_v
    if(isempty(n_list{i}))
        SF(i)=0;
    else
    SF(i)=mean(SFI(i,n_list{i}));
    end
end

link_metric=SFI;
node_metric=SF;