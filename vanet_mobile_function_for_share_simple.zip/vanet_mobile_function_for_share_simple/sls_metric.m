function [link_metric, node_metric]=sls_metric(n_v,dist,speed,loc,vd,max_dist,t_start,t_end,n_list)

max_v=40; %m/s

for i=1:n_v
    for j=1:n_v
        SLSI(i,j)=1/sqrt(1+(min(abs(dist(i,j,t_start))/max_dist,1))^2+ ((speed(i,t_start)-speed(j,t_start))/(2*max_v))^2);
     end
end



for i=1:n_v
    if(isempty(n_list{i}))
        SLS(i)=0;
    else
    SLS(i)=mean(SLSI(i,n_list{i}));
    end
end

link_metric=SLSI;
node_metric=SLS;