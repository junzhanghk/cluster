function [link_metric, node_metric]=rm_metric(n_v,dist,speed,loc,vd,max_dist,t_start,t_end,n_list)

for i=1:n_v
    for j=1:n_v
       if(abs(dist(i,j,t_start))>=max_dist)
           RM(i,j)=0;
       else
       RM(i,j)=10*log(1e-10+dist(i,j,t_start-1)/(1e-10+dist(i,j,t_start)))/log(10);
       end
end
end

for i=1:n_v
    if(isempty(n_list{i}))
        ALM(i)=0;
    else
    ALM(i)=-var(RM(i,n_list{i}));
    end
end

link_metric=RM;
node_metric=ALM;